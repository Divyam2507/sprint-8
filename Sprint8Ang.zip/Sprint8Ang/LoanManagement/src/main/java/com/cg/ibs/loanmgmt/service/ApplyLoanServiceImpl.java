package com.cg.ibs.loanmgmt.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.dao.AccountDao;
import com.cg.ibs.loanmgmt.dao.AccountHoldingDao;
import com.cg.ibs.loanmgmt.dao.BankerDao;
import com.cg.ibs.loanmgmt.dao.CustomerDao;
import com.cg.ibs.loanmgmt.dao.LoanMasterDao;
import com.cg.ibs.loanmgmt.dao.LoanTypeDao;
import com.cg.ibs.loanmgmt.entities.Account;
import com.cg.ibs.loanmgmt.entities.AccountHolding;
import com.cg.ibs.loanmgmt.entities.Banker;
import com.cg.ibs.loanmgmt.entities.LoanMasterEntity;
import com.cg.ibs.loanmgmt.entities.LoanStatus;
import com.cg.ibs.loanmgmt.model.AccountModel;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;

@Service("applyLoanService")
public class ApplyLoanServiceImpl implements ApplyLoanService {

	@Autowired
	private CustomerDao customerDao;
	@Autowired
	private LoanTypeDao loanTypeDao;
	@Autowired
	private AccountHoldingDao accountHoldingDao;
	@Autowired
	private LoanMasterDao loanMasterDao;
	@Autowired
	private AccountDao accountDao;
	@Autowired
	private BankerDao bankerDao;

	public LoanMasterEntity valueOf(LoanMasterModel loanModel) {
		LoanMasterEntity loanMasterEntity = new LoanMasterEntity();
		loanMasterEntity.setLoanAmount(loanModel.getLoanAmount());
		loanMasterEntity.setLoanTenure(loanModel.getLoanTenure());
		loanMasterEntity.setCustomer(customerDao.findByUserId(loanModel.getCustomerUserId()));
		loanMasterEntity.setLoanInterest(loanModel.getLoanInterest());
		loanMasterEntity.setLoanType(loanModel.getLoanType());
		loanMasterEntity.setEmiAmount(loanModel.getEmiAmount());
		loanMasterEntity.setEmiMode(loanModel.getEmiMode());
		loanMasterEntity.setSavings_Account(accountDao.findById(loanModel.getSavingsAccount()).get());
		return loanMasterEntity;
	}

	public LoanMasterModel valueOf(LoanMasterEntity loanMasterEntity) {
		LoanMasterModel loanMasterModel = new LoanMasterModel();
		loanMasterModel.setAppliedDate(loanMasterEntity.getAppliedDate());
		loanMasterModel.setApplicationNumber(loanMasterEntity.getApplicationNumber());
		loanMasterModel.setApprovedDate(loanMasterEntity.getApprovedDate());
		loanMasterModel.setBalance(loanMasterEntity.getBalance());
		loanMasterModel.setCustomerUserId(loanMasterEntity.getCustomer().getUserId());
		loanMasterModel.setEmiAmount(loanMasterEntity.getEmiAmount());
		loanMasterModel.setEmiMode(loanMasterEntity.getEmiMode());
		loanMasterModel.setLoanAmount(loanMasterEntity.getLoanAmount());
		loanMasterModel.setLoanTenure(loanMasterEntity.getLoanTenure());
		loanMasterModel.setLoanInterest(loanMasterEntity.getLoanInterest());
		loanMasterModel.setLoanType(loanMasterEntity.getLoanType());
		loanMasterModel.setLoanAccountNumber(loanMasterModel.getLoanAccountNumber());
		loanMasterModel.setLoanAccountNumber(loanMasterEntity.getLoanAccountNumber());
		loanMasterModel.setLoanClosedDate(loanMasterEntity.getLoanClosedDate());
		loanMasterModel.setLoanDeniedDate(loanMasterEntity.getLoanDeniedDate());
		loanMasterModel.setSavingsAccount(loanMasterEntity.getSavings_Account().getAccNo());
		loanMasterModel.setStatus(loanMasterEntity.getStatus());
		loanMasterModel.setNumOfEmisPaid(loanMasterEntity.getNumOfEmisPaid());
		loanMasterModel.setTotalNumOfEmis(loanMasterEntity.getTotalNumOfEmis());
		loanMasterModel.setNextEmiDate(loanMasterEntity.getNextEmiDate());
		return loanMasterModel;
	}

	@Transactional
	@Override
	public LoanMasterModel applyLoan(LoanMasterModel loanMasterModel) {
		LoanMasterEntity loanMasterEntity = valueOf(loanMasterModel);
		loanMasterEntity.setAppliedDate(LocalDate.now());
		loanMasterEntity.setStatus(LoanStatus.SENT_FOR_VERIFICATION);
		loanMasterEntity.setLoanApprover(appointBankAdmins());
		loanMasterEntity.setBalance(new BigDecimal("0.0"));
		loanMasterDao.save(loanMasterEntity);
		loanMasterModel = valueOf(loanMasterEntity);
		return loanMasterModel;
	}

	@Override
	public LoanMasterModel calculateEmi(LoanMasterModel loanMasterModel) {
		loanMasterModel.setLoanInterest((loanTypeDao.findById(loanMasterModel.getLoanTypeId()).get().getInterestRate()));
		loanMasterModel.setLoanType((loanTypeDao.findById(loanMasterModel.getLoanTypeId()).get().getLoanType()));
		Float rate = loanMasterModel.getLoanInterest() / (12 * 100);
		Double onePlusRPoweredN = Math.pow((rate + 1), loanMasterModel.getLoanTenure());
		BigDecimal principal = loanMasterModel.getLoanAmount();
		BigDecimal emi = principal.multiply(BigDecimal.valueOf((rate * onePlusRPoweredN) / (onePlusRPoweredN - 1)));
		loanMasterModel.setEmiAmount(emi.setScale(2, BigDecimal.ROUND_UP));
		return loanMasterModel;
	}

	@Override
	public List<AccountModel> findSavingsAccountsByCustomer(LoanMasterModel loanMasterModel) {
		List<AccountHolding> userSavingAccount = accountHoldingDao.findByCustomer(customerDao.findByUserId(loanMasterModel.getCustomerUserId()));
		List<AccountModel> userSavingsAccount = new ArrayList<AccountModel>();
		for (AccountHolding accountHolding : userSavingAccount) {
			Account acc = accountDao.findById(accountHolding.getAccount().getAccNo()).get();
			AccountModel accTemp = valueOf(acc);
			userSavingsAccount.add(accTemp);
		}
		return userSavingsAccount;
	}
	
	private AccountModel valueOf(Account account) {
		AccountModel accountModel = new AccountModel();
		accountModel.setAccNo(account.getAccNo());
		accountModel.setBalance(account.getBalance());
		accountModel.setAccCreationDate(account.getAccCreationDate());
		accountModel.setAccStatus(account.getAccStatus());
		accountModel.setAccType(account.getAccType());

		return accountModel;
	}
	
	private Banker appointBankAdmins() {
		List<Banker> registeredBankers = bankerDao.findAll();
		for (Banker banker : registeredBankers) {
			System.out.println(registeredBankers);	
		}
		Banker verifyLoanBanker;
		int lastBankAdminIndex = -1;
		BigInteger maxApplicationNumber = loanMasterDao.findMaxApplicationNumber();
		System.out.println(maxApplicationNumber);
		LoanMasterEntity latestLoan = loanMasterDao.findLoansByAppNum(maxApplicationNumber);
		if(latestLoan!=null) {
		lastBankAdminIndex = registeredBankers.indexOf(latestLoan.getLoanApprover());
		}
		if (lastBankAdminIndex == (registeredBankers.size() - 1) || lastBankAdminIndex == -1) {
			verifyLoanBanker = registeredBankers.get(0);
		}else {
			verifyLoanBanker = registeredBankers.get(lastBankAdminIndex + 1);
		}
		return verifyLoanBanker;
	}

	@Override
	public BigDecimal calculatePaidInterest(LoanMasterModel loanMasterModel) {
			BigDecimal balance = loanMasterModel.getBalance();
			Float rate = loanMasterModel.getLoanInterest() / 100;
			BigDecimal paidInterest = (balance.multiply(BigDecimal.valueOf(Math.pow(1 + rate, 1.0 / 12.0)))
					.subtract(balance));
			return paidInterest;
	
	
	}

	@Override
	public BigDecimal calculatePaidPrinciple(LoanMasterModel loanMasterModel) {
		BigDecimal paidPrinciple = loanMasterModel.getEmiAmount().subtract(calculatePaidInterest(loanMasterModel));
		return null;
	}

}
