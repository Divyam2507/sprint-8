package com.cg.ibs.loanmgmt.service;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.loanmgmt.ibsexception.IBSException;
import com.cg.ibs.loanmgmt.model.AccountModel;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;

public interface PayEmiService {
	List<LoanMasterModel> getApprovedLoanListByUserId(String userId) throws IBSException;

	LoanMasterModel getLoanByLoanNum(BigInteger loanAccountNumber) throws IBSException;
	
	List<AccountModel> findSavingsAccountsByCustomer(String userId,LoanMasterModel loanMasterModel) throws IBSException;

	LoanMasterModel updateLoanPostEmi(BigInteger loanAccountNumber , BigInteger savingsAccountNumber) throws IBSException;
	


//	TransactionBean createDebitTransaction(LoanMaster globalLoanMaster);
//
//	TransactionBean createCreditTransaction(LoanMaster globalLoanMaster);
//
//	CustomerBean getCustomer(String userId) throws IBSException;
}
