package com.cg.ibs.loanmgmt.entities;

public enum Gender {
	MALE, FEMALE, PREFER_NOT_TO_SAY;
}
