package com.cg.ibs.loanmgmt.service;

import java.math.BigDecimal;
import java.util.List;

import com.cg.ibs.loanmgmt.entities.AccountHolding;
import com.cg.ibs.loanmgmt.entities.LoanMasterEntity;
import com.cg.ibs.loanmgmt.model.AccountModel;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;

public interface ApplyLoanService {
	LoanMasterModel applyLoan(LoanMasterModel loanMasterModel);

	LoanMasterModel calculateEmi(LoanMasterModel loanMasterModel);

	List<AccountModel> findSavingsAccountsByCustomer(LoanMasterModel loanMasterModel);

	LoanMasterModel valueOf(LoanMasterEntity loanMasterEntity);

	LoanMasterEntity valueOf(LoanMasterModel loanModel);
	
	public BigDecimal calculatePaidInterest(LoanMasterModel loanMasterModel);

	public BigDecimal calculatePaidPrinciple(LoanMasterModel loanMasterModel);
}
